/*
Third program for testing
*/
int main();
int myint;
int addition(int a, double b);
int addition(int a, double b){
	int c;
	c = a+100;
int k = 4;
	if(k<4)
	{
		k--;
		c++;
		
	}
	return c;
}
int main(){
int ar1[5][10];
	double ar2[10];
double y;
	int z;
int i;
int x;
	z = addition(x,y);
	ar2[5] = ar1[2][3] + z;
	z = ar2[5];
	for(i=1;i<=z;i++){
		do{
			if(z>=5)
				z--;
		}while(z<=x);
		while(z<=ar2[5])
			ar2[5]++;
	}
	return z;
}
