/*
Fourth program for testing
*/
void func(int i, double d);
void func(int i, double d){
	int a = i|4;			
	int b = i - 1;			
	int z = 3;			
	i = i+ 3;
}


int main();
int main(){
	int x = 50, y = 13;		
	double b = 100.0;
int z = x + y;     
	int a = x*y;	
	double ans = b * x;	
	int ans = x * b; 
	int mod = x%y;  // Modulus
	int div = x/y;	// Division	
	double dif = x - b;	
	y++;	
	--x;	
	a = ~y; 
	b = -y;	
	return 0;
}
