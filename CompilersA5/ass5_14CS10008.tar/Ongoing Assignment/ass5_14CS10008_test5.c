/*
Fifth program for testing
*/
double max(int x, int y);
int main();
double max(int x, int y) {
       double ans;
       ans = (x > y)? x : y;
       return ans;
}

int main() {
       int a, b;
       a = a << 1;
       if(a > 10 || b == 0)
               a = 0;
       else
               a = 1;
	int tdog;
tdog = a * b;
a = tdog - b;
       tdog = max(a, b/2);
       return 0;
}
