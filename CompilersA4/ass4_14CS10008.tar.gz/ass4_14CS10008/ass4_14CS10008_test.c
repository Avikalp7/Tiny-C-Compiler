
static int x;
extern float y;

char* merafunction(char* c, int k, float c){
	int hanjibolo = vitolo;
	return merachar;
}

void merafunction_2(){
	return 0;
}

int main()
{
	// Checking declarations
	int a,b;
	int a[100];
	float c;
	double d,e;
	char f;
	char g[3] = {'h','e'};
	char* h;
	merafunction();
	int a = 6.0213E-23;
	int a = 6.0213e-23;
	float a = b + c;		// No semantic check as of now
	double d = c + a*b;
	double e = 3.4444;
	// checking unary
	a++;
	b--;
	b=++a;
	b=a++;
	a=b--;
	a=--b;
	// checking binary
	a = b & 1;
	a = a | 1;
	a = a ^ 2;
	a = !a;
	a = a * c;
	a = a / b;
	a = a + b;
	a = a % 3;
	a+=2;
	b-=3;
	c*=d;
	c/=5;
	c%=1;
	c<<=2;
	c>>=z;
	c&=2;
	c|=1;
	c^=0;
	int b = a && c;
	int bb = b || (c==r) && (!a);

	/* please multi comment recog
	nize ho jana
	peace out

	*/

	while(i!=0){
		switch(i){
			case 0: 
			i++;
			break;
			case 1:
			--i;
			if(!i){
				i=1;
			}
			else if(i==1){
				i=0;
			}
			else{
				for(i=11;i<=100;i++)
					i = i+1;
			}
			break;
		}
	}

	return 0;
	
	
}
